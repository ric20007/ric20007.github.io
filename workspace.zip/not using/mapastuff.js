$(document).ready(function() {

  
    $('#mapa').draggable();
    
});
